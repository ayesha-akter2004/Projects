<?php

echo $_REQUEST['fname'];
echo $_REQUEST['lname'];


?>
